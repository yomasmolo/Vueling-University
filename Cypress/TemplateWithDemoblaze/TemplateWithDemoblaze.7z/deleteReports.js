const fs = require("fs");
fs.rmdirSync("./cypress/reports", { recursive: true });
